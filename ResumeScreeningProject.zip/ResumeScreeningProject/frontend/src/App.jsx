import "./App.css";
import { useEffect, useMemo, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api";

const defaultSkills = [
  { name: "Python", weight: 40 },
  { name: "Machine Learning", weight: 30 },
  { name: "SQL", weight: 20 },
  { name: "Communication", weight: 10 },
];

function getName(candidate) {
  const name = candidate.name || candidate.candidateName || candidate.fullName || "";

  if (
    name.trim() &&
    !["not found", "unknown", "n/a"].includes(name.trim().toLowerCase())
  ) {
    return name.trim();
  }

  const emailPart = (candidate.email || "").split("@")[0];

  if (emailPart) {
    return emailPart
      .replace(/[._-]+/g, " ")
      .replace(/\b\w/g, x => x.toUpperCase());
  }

  const path = candidate.resume_path || candidate.filename || "";

  if (path) {
    return path
      .split(/[\\/]/)
      .pop()
      .replace(/\.[^.]+$/, "")
      .replace(/[_-]+/g, " ");
  }

  return "Unnamed Candidate";
}

function getSkills(candidate) {
  if (Array.isArray(candidate.skills)) return candidate.skills;

  try {
    const parsed = JSON.parse(candidate.skills || "[]");
    return Array.isArray(parsed)
      ? parsed
      : [];
  } catch {
    return (candidate.skills || "")
      .split(",")
      .map(x => x.trim())
      .filter(Boolean);
  }
}

function App() {
  const [page, setPage] = useState("Dashboard");
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [candidates, setCandidates] = useState([]);
  const [profile, setProfile] = useState(null);

  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("success");
  const [backendOnline, setBackendOnline] = useState(false);
  const [loading, setLoading] = useState(false);

  const [title, setTitle] = useState("");
  const [qualification, setQualification] = useState("");
  const [experience, setExperience] = useState("Fresher");
  const [skills, setSkills] = useState(defaultSkills);
  const [newSkill, setNewSkill] = useState("");

  const [files, setFiles] = useState([]);
  const [dragActive, setDragActive] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const totalWeight = skills.reduce(
    (sum, item) => sum + Number(item.weight || 0),
    0
  );

  const selectedJob = jobs.find(
    job => String(job.id) === String(jobId)
  );

  const sortedCandidates = useMemo(() => {
    return [...candidates].sort(
      (a, b) => Number(b.score || 0) - Number(a.score || 0)
    );
  }, [candidates]);

  const filteredCandidates = useMemo(() => {
    return sortedCandidates.filter(candidate => {
      const name = getName(candidate).toLowerCase();
      const email = (candidate.email || "").toLowerCase();
      const skillText = getSkills(candidate)
        .map(skill => typeof skill === "string" ? skill : skill.name)
        .join(" ")
        .toLowerCase();

      const search = searchTerm.toLowerCase();

      const matchesSearch =
        name.includes(search) ||
        email.includes(search) ||
        skillText.includes(search);

      const status = (candidate.status || "Pending").toLowerCase();

      const matchesStatus =
        statusFilter === "All" ||
        status === statusFilter.toLowerCase();

      return matchesSearch && matchesStatus;
    });
  }, [sortedCandidates, searchTerm, statusFilter]);

  const averageScore = candidates.length
    ? (
        candidates.reduce(
          (sum, candidate) => sum + Number(candidate.score || 0),
          0
        ) / candidates.length
      ).toFixed(1)
    : "0.0";

  const selectedCount = candidates.filter(
    c => (c.status || "").toLowerCase() === "selected"
  ).length;

  const pendingCount = candidates.filter(
    c => !c.status || c.status.toLowerCase() === "pending"
  ).length;

  useEffect(() => {
    checkBackend();
    loadJobs();
  }, []);

  useEffect(() => {
    if (jobId) {
      loadCandidates(jobId);
    } else {
      setCandidates([]);
    }
  }, [jobId]);

  function showMessage(text, type = "success") {
    setMessage(text);
    setMessageType(type);
  }

  async function checkBackend() {
    try {
      const response = await fetch(`${API}/health`);
      const data = await response.json();
      setBackendOnline(Boolean(data.success));
    } catch {
      setBackendOnline(false);
    }
  }

  async function loadJobs() {
    try {
      const response = await fetch(`${API}/jobs`);
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Unable to load jobs.");
      }

      const jobList = data.jobs || [];
      setJobs(jobList);

      setJobId(currentId => {
        if (jobList.some(job => String(job.id) === String(currentId))) {
          return currentId;
        }

        return jobList.length ? String(jobList[0].id) : "";
      });
    } catch (error) {
      showMessage(
        error.message || "Could not connect to the backend.",
        "error"
      );
    }
  }

  async function loadCandidates(id) {
    try {
      const response = await fetch(`${API}/jobs/${id}/candidates`);
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Unable to load candidates.");
      }

      setCandidates(data.candidates || []);
    } catch (error) {
      showMessage(error.message, "error");
    }
  }

  function updateSkill(index, field, value) {
    setSkills(old =>
      old.map((skill, i) =>
        i === index
          ? { ...skill, [field]: value }
          : skill
      )
    );
  }

  function addSkill() {
    const name = newSkill.trim();

    if (!name) {
      showMessage("Please enter a skill name.", "error");
      return;
    }

    if (
      skills.some(
        skill => skill.name.toLowerCase() === name.toLowerCase()
      )
    ) {
      showMessage("This skill has already been added.", "error");
      return;
    }

    setSkills(old => [...old, { name, weight: 0 }]);
    setNewSkill("");
    showMessage("Skill added. Remember to adjust the weights.");
  }

  async function createJob(event) {
    event.preventDefault();

    if (!title.trim() || !qualification.trim()) {
      showMessage("Please enter the job title and qualification.", "error");
      return;
    }

    if (!skills.length) {
      showMessage("Please add at least one required skill.", "error");
      return;
    }

    if (skills.some(skill => !skill.name.trim())) {
      showMessage("Every skill must have a name.", "error");
      return;
    }

    if (
      skills.some(
        skill =>
          !Number.isFinite(Number(skill.weight)) ||
          Number(skill.weight) < 0 ||
          Number(skill.weight) > 100
      )
    ) {
      showMessage("Skill weights must be between 0 and 100.", "error");
      return;
    }

    if (totalWeight !== 100) {
      showMessage(
        `Your skill weights currently total ${totalWeight}%. They must total exactly 100%.`,
        "error"
      );
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const response = await fetch(`${API}/jobs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          qualification,
          experience,
          skills
        })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Job creation failed.");
      }

      setTitle("");
      setQualification("");
      setExperience("Fresher");
      setSkills(defaultSkills);

      await loadJobs();

      showMessage("Your job requirement was created successfully!");
      setPage("Dashboard");
    } catch (error) {
      showMessage(error.message, "error");
    } finally {
      setLoading(false);
    }
  }

  async function deleteJob(id) {
    if (!window.confirm(
      "Are you sure you want to delete this job requirement?"
    )) return;

    try {
      const response = await fetch(`${API}/jobs/${id}`, {
        method: "DELETE"
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Could not delete job.");
      }

      if (String(id) === String(jobId)) {
        setCandidates([]);
      }

      await loadJobs();
      showMessage("Job requirement deleted.");
    } catch (error) {
      showMessage(error.message, "error");
    }
  }

  function addSelectedFiles(selected) {
    const valid = selected.filter(file =>
      /\.(pdf|doc|docx|txt)$/i.test(file.name)
    );

    setFiles(old => {
      const combined = [...old, ...valid];

      return combined.filter((file, index, array) =>
        array.findIndex(
          x =>
            x.name === file.name &&
            x.size === file.size &&
            x.lastModified === file.lastModified
        ) === index
      );
    });

    if (selected.length !== valid.length) {
      showMessage(
        "Some files were skipped. Only PDF, DOC, DOCX and TXT are supported.",
        "error"
      );
    } else if (valid.length) {
      showMessage(`${valid.length} valid resume file(s) added.`);
    }
  }

  function selectFiles(event) {
    addSelectedFiles(Array.from(event.target.files || []));
    event.target.value = "";
  }

  function handleDrop(event) {
    event.preventDefault();
    setDragActive(false);
    addSelectedFiles(Array.from(event.dataTransfer.files || []));
  }

  async function uploadResumes() {
    if (!jobId) {
      showMessage("Please select a job position first.", "error");
      return;
    }

    if (!files.length) {
      showMessage("Please choose at least one resume.", "error");
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const formData = new FormData();
      formData.append("jobId", jobId);

      files.forEach(file => {
        formData.append("resumes", file);
      });

      const response = await fetch(`${API}/upload-resumes`, {
        method: "POST",
        body: formData
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Resume upload failed.");
      }

      setFiles([]);
      await loadCandidates(jobId);

      showMessage(data.message || "Resumes uploaded successfully!");
      setPage("Candidates");
    } catch (error) {
      showMessage(error.message, "error");
    } finally {
      setLoading(false);
    }
  }

  async function calculateScores() {
    if (!jobId) {
      showMessage("Please select a job position first.", "error");
      return;
    }

    if (!candidates.length) {
      showMessage("Upload resumes before calculating scores.", "error");
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const response = await fetch(`${API}/jobs/${jobId}/score`, {
        method: "POST"
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Scoring failed.");
      }

      await loadCandidates(jobId);

      showMessage("Candidate scores calculated and ranked successfully!");
      setPage("Candidates");
    } catch (error) {
      showMessage(error.message, "error");
    } finally {
      setLoading(false);
    }
  }

  async function updateStatus(applicationId, status) {
    if (!applicationId) {
      showMessage("Candidate application ID is missing.", "error");
      return;
    }

    if (
      status === "Rejected" &&
      !window.confirm("Are you sure you want to reject this candidate?")
    ) return;

    try {
      const response = await fetch(
        `${API}/applications/${applicationId}/status`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status })
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Status update failed.");
      }

      await loadCandidates(jobId);
      setProfile(null);

      showMessage(`Candidate marked as ${status}.`);
    } catch (error) {
      showMessage(error.message, "error");
    }
  }

  function navigate(destination) {
    setPage(destination);
    setMessage("");
  }

  const navItems = [
    { label: "Dashboard", icon: "⌂" },
    { label: "Create Job", icon: "＋" },
    { label: "Resume Screening", icon: "▤" },
    { label: "Candidates", icon: "♙" },
    { label: "Help", icon: "?" },
    { label: "Settings", icon: "⚙" }
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">H</div>
          <div>
            <h2>HireSmart</h2>
            <span>Resume Intelligence</span>
          </div>
        </div>

        <div className="sidebar-label">WORKSPACE</div>

        <nav className="navigation">
          {navItems.map(item => (
            <button
              key={item.label}
              className={`nav-link ${page === item.label ? "active" : ""}`}
              onClick={() => navigate(item.label)}
              title={item.label}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {page === item.label && <span className="nav-indicator" />}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="connection-indicator">
            <span className={`connection-dot ${backendOnline ? "" : "offline"}`} />
            <span>{backendOnline ? "System connected" : "Backend offline"}</span>
          </div>

          <div className="sidebar-user">
            <div className="user-avatar">R</div>
            <div>
              <strong>Recruiter</strong>
              <small>Administrator</small>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="top-header">
          <div>
            <div className="breadcrumb">
              Workspace <span>/</span> {page}
            </div>
            <h1>{page}</h1>
          </div>

          <div className="header-right">
            <div className="header-date">Recruitment workspace</div>
            <div className="header-avatar">R</div>
          </div>
        </header>

        {message && (
          <div className={`alert-message ${messageType}`}>
            <span>{message}</span>
            <button onClick={() => setMessage("")} aria-label="Close message">
              ×
            </button>
          </div>
        )}

        {page === "Dashboard" && (
          <>
            <section className="hero-panel">
              <div className="hero-copy">
                <span className="eyebrow">SMARTER RECRUITMENT STARTS HERE</span>
                <h2>Find your next<br />great hire.</h2>
                <p>
                  Screen resumes, compare skills and discover suitable candidates.
                  HireSmart helps make recruitment easier.
                </p>
                <button
                  className="button-primary"
                  onClick={() => navigate("Create Job")}
                >
                  ＋ Create a job
                </button>
              </div>

              <div className="hero-visual">
                <div className="hero-orbit orbit-one" />
                <div className="hero-orbit orbit-two" />
                <div className="hero-document">
                  <div className="doc-top"><span /><span /><span /></div>
                  <div className="doc-avatar">R</div>
                  <div className="doc-line long" />
                  <div className="doc-line medium" />
                  <div className="doc-line short" />
                  <div className="doc-score">
                    92.8% <small>Match score</small>
                  </div>
                </div>
                <div className="floating-chip chip-top">✦ AI matching</div>
                <div className="floating-chip chip-bottom">✓ Top candidate</div>
              </div>
            </section>

            <div className="quick-actions">
              <button onClick={() => navigate("Create Job")}>
                <span>＋</span>
                <div><strong>Create a job</strong><small>Set your requirements</small></div>
              </button>
              <button onClick={() => navigate("Resume Screening")}>
                <span>↑</span>
                <div><strong>Upload resumes</strong><small>Add candidate files</small></div>
              </button>
              <button onClick={() => navigate("Candidates")}>
                <span>♙</span>
                <div><strong>View candidates</strong><small>Explore candidate rankings</small></div>
              </button>
            </div>

            <section className="stats-grid">
              <div className="stat-card">
                <div className="stat-top">
                  <span className="stat-icon blue">▤</span>
                  <span className="stat-caption">JOB POSTS</span>
                </div>
                <h2>{jobs.length}</h2>
                <p>Created positions</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span className="stat-icon violet">♙</span>
                  <span className="stat-caption">CANDIDATES</span>
                </div>
                <h2>{candidates.length}</h2>
                <p>In selected position</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span className="stat-icon green">↗</span>
                  <span className="stat-caption">AVERAGE MATCH</span>
                </div>
                <h2>{averageScore}<small>%</small></h2>
                <p>Average candidate score</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span className="stat-icon orange">✓</span>
                  <span className="stat-caption">SELECTED</span>
                </div>
                <h2>{selectedCount}</h2>
                <p>Selected candidates</p>
              </div>
            </section>

            <section className="content-card">
              <div className="card-heading">
                <div>
                  <h2>Job positions</h2>
                  <p>Your recruitment requirements</p>
                </div>
                <button
                  className="button-secondary"
                  onClick={() => navigate("Create Job")}
                >
                  ＋ New job
                </button>
              </div>

              {jobs.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">▤</div>
                  <h3>Let's create your first job!</h3>
                  <p>
                    Start by entering a job title, qualification and required skills.
                  </p>
                  <button
                    className="button-primary"
                    onClick={() => navigate("Create Job")}
                  >
                    Create first job
                  </button>
                </div>
              ) : (
                <div className="job-list">
                  {jobs.map(job => (
                    <div className="job-item" key={job.id}>
                      <div className="job-symbol">JD</div>
                      <div className="job-description">
                        <strong>{job.title || job.jobTitle}</strong>
                        <span>
                          {job.qualification || "Qualification not specified"}
                        </span>
                      </div>
                      <button
                        className="text-button"
                        onClick={() => {
                          setJobId(String(job.id));
                          navigate("Candidates");
                        }}
                      >
                        View candidates →
                      </button>
                      <button
                        className="icon-delete"
                        title="Delete job"
                        onClick={() => deleteJob(job.id)}
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}

        {page === "Create Job" && (
          <section className="content-card form-card">
            <div className="card-heading">
              <div>
                <h2>Create job requirement</h2>
                <p>Tell HireSmart what kind of candidate you're looking for.</p>
              </div>
              <span className="step-label">JOB SETUP</span>
            </div>

            <div className="helper-banner">
              <span>💡</span>
              <p>
                First, enter the position details. Then add the skills that matter
                most for this job. Their weights must add up to 100%.
              </p>
            </div>

            <form onSubmit={createJob}>
              <div className="form-section-title">
                <span>01</span>
                <div>
                  <h3>Position details</h3>
                  <p>Basic information about the role</p>
                </div>
              </div>

              <div className="form-grid">
                <label>
                  Job title
                  <input
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="e.g. Software Developer"
                    required
                  />
                </label>

                <label>
                  Required qualification
                  <input
                    value={qualification}
                    onChange={e => setQualification(e.target.value)}
                    placeholder="e.g. BTech Computer Science"
                    required
                  />
                </label>

                <label>
                  Experience level
                  <select
                    value={experience}
                    onChange={e => setExperience(e.target.value)}
                  >
                    <option>Fresher</option>
                    <option>0-1 Years</option>
                    <option>1-2 Years</option>
                    <option>2-3 Years</option>
                    <option>3-5 Years</option>
                    <option>5+ Years</option>
                  </select>
                </label>
              </div>

              <div className="form-divider" />

              <div className="form-section-title">
                <span>02</span>
                <div>
                  <h3>Skill requirements</h3>
                  <p>Give more importance to the skills that matter most</p>
                </div>
              </div>

              <div className="weight-summary">
                <div>
                  <strong>Skill importance</strong>
                  <span>All skill weights together must equal 100%</span>
                </div>
                <strong className={totalWeight === 100 ? "weight-good" : "weight-warning"}>
                  {totalWeight}% <small>/ 100%</small>
                </strong>
              </div>

              <div className="weight-progress">
                <span
                  className={totalWeight === 100 ? "complete" : ""}
                  style={{ width: `${Math.min(100, Math.max(0, totalWeight))}%` }}
                />
              </div>

              <div className="skill-list">
                {skills.map((skill, index) => (
                  <div className="skill-editor" key={index}>
                    <input
                      value={skill.name}
                      onChange={e =>
                        updateSkill(index, "name", e.target.value)
                      }
                      placeholder="Skill name"
                    />
                    <div className="weight-input">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={skill.weight}
                        onChange={e =>
                          updateSkill(index, "weight", Number(e.target.value))
                        }
                      />
                      <span>%</span>
                    </div>
                    <button
                      type="button"
                      className="remove-skill"
                      onClick={() =>
                        setSkills(old => old.filter((_, i) => i !== index))
                      }
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>

              <div className="add-skill">
                <input
                  value={newSkill}
                  onChange={e => setNewSkill(e.target.value)}
                  placeholder="Add another skill..."
                  onKeyDown={e => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addSkill();
                    }
                  }}
                />
                <button
                  type="button"
                  className="button-secondary"
                  onClick={addSkill}
                >
                  ＋ Add skill
                </button>
              </div>

              <div className="form-actions">
                <button
                  type="button"
                  className="button-ghost"
                  onClick={() => {
                    setTitle("");
                    setQualification("");
                    setExperience("Fresher");
                    setSkills(defaultSkills);
                    setNewSkill("");
                    setMessage("");
                  }}
                >
                  Reset form
                </button>

                <button
                  className="button-primary"
                  type="submit"
                  disabled={loading}
                >
                  {loading ? "Saving..." : "Save job requirement →"}
                </button>
              </div>
            </form>
          </section>
        )}

        {page === "Resume Screening" && (
          <section className="content-card">
            <div className="card-heading">
              <div>
                <h2>Resume screening</h2>
                <p>Upload resumes and let HireSmart analyse candidate profiles.</p>
              </div>
              <span className="step-label">SCREENING</span>
            </div>

            <div className="helper-banner">
              <span>📄</span>
              <p>
                Select the job first. Then upload one or more candidate resumes.
                HireSmart supports PDF, DOC, DOCX and TXT files.
              </p>
            </div>

            <div className="upload-form">
              <label className="field-label">Choose job position</label>
              <select
                className="full-select"
                value={jobId}
                onChange={e => setJobId(e.target.value)}
              >
                <option value="">Select a job position</option>
                {jobs.map(job => (
                  <option key={job.id} value={job.id}>
                    {job.title || job.jobTitle}
                  </option>
                ))}
              </select>

              {jobs.length === 0 && (
                <p className="inline-help">
                  You haven't created a job yet.{" "}
                  <button onClick={() => navigate("Create Job")}>
                    Create a job first
                  </button>
                </p>
              )}

              <label
                className={`upload-zone ${dragActive ? "drag-active" : ""}`}
                onDragOver={e => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
              >
                <input
                  type="file"
                  multiple
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={selectFiles}
                />
                <span className="upload-cloud">↑</span>
                <strong>Drop resumes here or <u>browse files</u></strong>
                <span>PDF, DOC, DOCX and TXT files are supported</span>
                <small>Choose multiple resumes at once</small>
              </label>

              {files.length > 0 && (
                <div className="file-list">
                  <div className="file-list-heading">
                    Selected resumes ({files.length})
                  </div>

                  {files.map((file, index) => (
                    <div className="file-item" key={`${file.name}-${index}`}>
                      <span className="file-icon">FILE</span>
                      <div>
                        <strong>{file.name}</strong>
                        <small>{(file.size / 1024).toFixed(1)} KB</small>
                      </div>
                      <button
                        onClick={() =>
                          setFiles(old => old.filter((_, i) => i !== index))
                        }
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <button
                className="button-primary"
                onClick={uploadResumes}
                disabled={loading || !jobId || !files.length}
              >
                {loading ? "Uploading..." : `Upload ${files.length || ""} resumes →`}
              </button>
            </div>

            <div className="screening-box">
              <div className="screening-icon">✦</div>
              <div>
                <h3>Ready to rank candidates?</h3>
                <p>
                  After uploading resumes, calculate the match scores to compare
                  candidates against your job requirements.
                </p>
              </div>
              <button
                className="button-secondary"
                onClick={calculateScores}
                disabled={loading || !jobId || !candidates.length}
              >
                {loading ? "Processing..." : "Calculate scores"}
              </button>
            </div>
          </section>
        )}

        {page === "Candidates" && (
          <section className="content-card">
            <div className="card-heading">
              <div>
                <h2>Candidate rankings</h2>
                <p>Compare candidates based on their match with the job requirements.</p>
              </div>
              <button
                className="button-secondary"
                onClick={() => jobId && loadCandidates(jobId)}
                disabled={!jobId}
              >
                ↻ Refresh
              </button>
            </div>

            <div className="candidate-toolbar">
              <div>
                <label className="field-label">Job position</label>
                <select
                  className="full-select"
                  value={jobId}
                  onChange={e => setJobId(e.target.value)}
                >
                  <option value="">Select a job position</option>
                  {jobs.map(job => (
                    <option key={job.id} value={job.id}>
                      {job.title || job.jobTitle}
                    </option>
                  ))}
                </select>
              </div>

              <div className="candidate-count">
                <strong>{candidates.length}</strong>
                <span>total candidates</span>
              </div>
            </div>

            {!jobId ? (
              <div className="empty-state">
                <div className="empty-icon">♙</div>
                <h3>Select a job position</h3>
                <p>Choose a job to see its ranked candidates.</p>
              </div>
            ) : candidates.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">♙</div>
                <h3>No candidates yet</h3>
                <p>Upload resumes for this job to start screening.</p>
                <button
                  className="button-primary"
                  onClick={() => navigate("Resume Screening")}
                >
                  Upload resumes
                </button>
              </div>
            ) : (
              <>
                <div className="candidate-summary">
                  <div><strong>{candidates.length}</strong><span>All candidates</span></div>
                  <div><strong>{selectedCount}</strong><span>Selected</span></div>
                  <div><strong>{pendingCount}</strong><span>Pending</span></div>
                </div>

                <div className="candidate-filters">
                  <div className="search-box">
                    <span>⌕</span>
                    <input
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      placeholder="Search by name, email or skill..."
                    />
                  </div>

                  <select
                    value={statusFilter}
                    onChange={e => setStatusFilter(e.target.value)}
                    aria-label="Filter candidates by status"
                  >
                    <option value="All">All statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="Selected">Selected</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>

                {filteredCandidates.length === 0 ? (
                  <div className="empty-state">
                    <h3>No matching candidates</h3>
                    <p>Try a different search term or status filter.</p>
                    <button
                      className="button-secondary"
                      onClick={() => {
                        setSearchTerm("");
                        setStatusFilter("All");
                      }}
                    >
                      Clear filters
                    </button>
                  </div>
                ) : (
                  <div className="table-scroll">
                    <table className="candidate-table">
                      <thead>
                        <tr>
                          <th>RANK / CANDIDATE</th>
                          <th>EMAIL</th>
                          <th>SKILLS</th>
                          <th>MATCH SCORE</th>
                          <th>STATUS</th>
                          <th>ACTIONS</th>
                        </tr>
                      </thead>

                      <tbody>
                        {filteredCandidates.map((candidate, index) => (
                          <tr key={candidate.applicationId || candidate.id || index}>
                            <td>
                              <div className="candidate-cell">
                                <span className="rank-number">#{index + 1}</span>
                                <strong>{getName(candidate)}</strong>
                              </div>
                            </td>

                            <td>{candidate.email || "Not available"}</td>

                            <td>
                              <div className="skill-tags">
                                {getSkills(candidate).slice(0, 3).map((skill, i) => (
                                  <span key={i}>
                                    {typeof skill === "string" ? skill : skill.name}
                                  </span>
                                ))}
                              </div>
                            </td>

                            <td>
                              <div className="score-cell">
                                <strong>
                                  {Number(candidate.score || 0).toFixed(1)}%
                                </strong>
                                <div className="score-track">
                                  <span
                                    style={{
                                      width: `${Math.min(
                                        100,
                                        Math.max(0, Number(candidate.score || 0))
                                      )}%`
                                    }}
                                  />
                                </div>
                              </div>
                            </td>

                            <td>
                              <span
                                className={`status-pill ${(candidate.status || "Pending").toLowerCase()}`}
                              >
                                {candidate.status || "Pending"}
                              </span>
                            </td>

                            <td>
                              <div className="table-actions">
                                <button
                                  className="view-action"
                                  onClick={() => setProfile(candidate)}
                                >
                                  View
                                </button>
                                <button
                                  className="select-action"
                                  onClick={() =>
                                    updateStatus(candidate.applicationId, "Selected")
                                  }
                                >
                                  Select
                                </button>
                                <button
                                  className="reject-action"
                                  onClick={() =>
                                    updateStatus(candidate.applicationId, "Rejected")
                                  }
                                >
                                  Reject
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {page === "Help" && (
          <section className="content-card help-page">
            <div className="card-heading">
              <div>
                <h2>Welcome to HireSmart Help</h2>
                <p>A simple guide to using your recruitment workspace.</p>
              </div>
              <span className="step-label">USER GUIDE</span>
            </div>

            <div className="help-intro">
              <h3>Screen resumes in four easy steps</h3>
              <p>
                You don't need technical knowledge to use HireSmart.
                Follow these steps to find suitable candidates.
              </p>
            </div>

            <div className="help-steps">
              <div className="help-step">
                <span>01</span>
                <div>
                  <h3>Create a job</h3>
                  <p>
                    Enter the job title, required qualification and experience.
                    Add important skills and distribute their weights until
                    the total reaches 100%.
                  </p>
                  <button className="text-button" onClick={() => navigate("Create Job")}>
                    Go to Create Job →
                  </button>
                </div>
              </div>

              <div className="help-step">
                <span>02</span>
                <div>
                  <h3>Upload resumes</h3>
                  <p>
                    Choose a job position and upload resumes in PDF, DOC,
                    DOCX or TXT format. You can select multiple files.
                  </p>
                  <button
                    className="text-button"
                    onClick={() => navigate("Resume Screening")}
                  >
                    Go to Resume Screening →
                  </button>
                </div>
              </div>

              <div className="help-step">
                <span>03</span>
                <div>
                  <h3>Calculate match scores</h3>
                  <p>
                    Run the scoring process. HireSmart compares the candidate
                    information with the job requirements and calculates match scores.
                  </p>
                  <button
                    className="text-button"
                    onClick={() => navigate("Resume Screening")}
                  >
                    Calculate scores →
                  </button>
                </div>
              </div>

              <div className="help-step">
                <span>04</span>
                <div>
                  <h3>Review candidates</h3>
                  <p>
                    Compare ranked candidates, search by name or skill, open
                    profiles and update their status to Selected or Rejected.
                  </p>
                  <button
                    className="text-button"
                    onClick={() => navigate("Candidates")}
                  >
                    View candidates →
                  </button>
                </div>
              </div>
            </div>

            <div className="help-note">
              <strong>Important reminder</strong>
              <p>
                A match score is an automated recommendation, not a hiring decision.
                Always review candidate profiles and make fair decisions yourself.
              </p>
            </div>
          </section>
        )}

        {page === "Settings" && (
          <section className="content-card settings-card">
            <div className="card-heading">
              <div>
                <h2>Settings</h2>
                <p>Application information and system status.</p>
              </div>
            </div>

            <div className="settings-list">
              <div><span>Application name</span><strong>HireSmart</strong></div>
              <div><span>Frontend</span><strong>React + CSS</strong></div>
              <div><span>Backend</span><strong>Node.js + Express</strong></div>
              <div><span>Machine learning</span><strong>Python</strong></div>
              <div><span>Database</span><strong>MySQL</strong></div>
              <div>
                <span>Backend connection</span>
                <strong className={backendOnline ? "weight-good" : "weight-warning"}>
                  {backendOnline ? "Connected" : "Disconnected"}
                </strong>
              </div>
              <div><span>API address</span><strong>localhost:5000</strong></div>
            </div>

            <button className="button-secondary" onClick={checkBackend}>
              Check connection
            </button>
          </section>
        )}

        <footer className="page-footer">
          HireSmart <span>•</span> ML-Based Resume Screening and Ranking System
        </footer>
      </main>

      {profile && (
        <div className="modal-backdrop" onClick={() => setProfile(null)}>
          <section
            className="profile-modal"
            onClick={e => e.stopPropagation()}
          >
            <button
              className="modal-close"
              onClick={() => setProfile(null)}
              aria-label="Close profile"
            >
              ×
            </button>

            <div className="profile-heading">
              <div className="profile-avatar">
                {getName(profile).charAt(0).toUpperCase()}
              </div>
              <div>
                <span className="eyebrow">CANDIDATE PROFILE</span>
                <h2>{getName(profile)}</h2>
                <p>{profile.email || "Email not available"}</p>
              </div>
            </div>

            <div className="profile-score">
              <span>ML match score</span>
              <strong>{Number(profile.score || 0).toFixed(1)}%</strong>
            </div>

            <div className="profile-details">
              <div>
                <span>Phone</span>
                <strong>{profile.phone || "Not available"}</strong>
              </div>
              <div>
                <span>Skills</span>
                <strong>
                  {getSkills(profile)
                    .map(s => typeof s === "string" ? s : s.name)
                    .join(", ") || "Not available"}
                </strong>
              </div>
              <div>
                <span>Education</span>
                <strong>{profile.education || "Not available"}</strong>
              </div>
              <div>
                <span>Experience</span>
                <strong>{profile.experience || "Not available"}</strong>
              </div>
              <div>
                <span>Projects</span>
                <strong>
                  {Array.isArray(profile.projects)
                    ? profile.projects.join(", ")
                    : profile.projects || "Not available"}
                </strong>
              </div>
              <div>
                <span>Current status</span>
                <strong>{profile.status || "Pending"}</strong>
              </div>
            </div>

            <div className="profile-actions">
              <button
                className="button-primary"
                onClick={() =>
                  updateStatus(profile.applicationId, "Selected")
                }
              >
                Select candidate
              </button>
              <button
                className="button-danger"
                onClick={() =>
                  updateStatus(profile.applicationId, "Rejected")
                }
              >
                Reject candidate
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;
